-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 11, 2018 at 11:17 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `student`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_panel`
--

CREATE TABLE IF NOT EXISTS `admin_panel` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin_panel`
--

INSERT INTO `admin_panel` (`id`, `admin_name`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'shriyansh', 'shriyansh123');

-- --------------------------------------------------------

--
-- Table structure for table `student_data`
--

CREATE TABLE IF NOT EXISTS `student_data` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `student_id` bigint(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `age` int(2) NOT NULL,
  `date_of_birth` date NOT NULL,
  `email_id` varchar(40) NOT NULL,
  `mobile_no` bigint(10) NOT NULL,
  `address` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `student_data`
--

INSERT INTO `student_data` (`id`, `student_id`, `name`, `age`, `date_of_birth`, `email_id`, `mobile_no`, `address`) VALUES
(17, 156, 'Amit Rawat', 23, '1995-07-12', 'amitrawat@gmail.com', 1288372973, 'Dehradun'),
(6, 20, 'saumya gupta', 20, '2018-06-07', 'shriyanshgupta123@gmail.com', 9794328009, 'H.N-11/144 Anandpuram colony'),
(16, 12, 'SHRIYANSH GUPTA', 22, '2018-06-13', 'shriyanshgupta123@gmail.com', 9794328009, '4 Anandpuram colony'),
(15, 219, 'SHRIYANSH ', 16, '2002-07-26', 'shriyanshgupta123@gmail.com', 9794328009, ' Anandpuram colony');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
